# 🐢 Turtle Website

Simple static website about turtles.

## Features
- Calm green theme
- Sections: Home, Types, Gallery

## How to Run
Open `index.html` in your browser.

## Author
Gudhal Production
